from django.shortcuts import render,redirect
def base(request):
    return render(request, "base.html")

def instructor_login(request):
    return render(request, "instructor_login.html")

def instructor_register(request):
    return render(request, "instructor_register.html")

def instructor_manage(request):
    return render(request, "instructor_manage.html")

def instructor_course_bank(request):
    return render(request, "instructor_course_bank.html")

def instructor_view_course(request):
    return render(request, "instructor_view_course.html")

def instructor_add_resource(request):
    return render(request, "instructor_add_resource.html")

def instructor_add_course(request):
    return render(request, "instructor_add_course.html")

def instructor_forgot_password(request):
    return render(request, "instructor_forgot_password.html")

def instructor_view_courseinfo(request):
    return render(request, "instructor_view_courseinfo.html")
